# Week 5 Comprehensive Data Science Project
## Customer Churn Prediction & Retention Strategy

### Project objective
Build an end-to-end data science workflow that converts customer data into churn-risk insights and actionable retention recommendations.

### Contents
- `Week_5_Comprehensive_Data_Science_Project_Report.docx` — final report
- `customer_churn_analysis.py` — reproducible Python analysis
- `README.md` — project documentation

### Workflow
1. Data generation/preparation
2. Exploratory data analysis
3. Train/test split
4. Logistic Regression and Random Forest
5. Evaluation using Accuracy, Precision, Recall, F1 and ROC-AUC
6. Business interpretation
7. Strategic retention recommendations

### Important note
The numerical analysis in this portfolio version uses a synthetic dataset because the original Week 1-4 dataset/notebook was not supplied. Replace the synthetic data and results with the student's actual project outputs before final submission if required.

### Suggested GitHub repository structure
```text
Week5-Churn-Data-Science-Project/
├── README.md
├── customer_churn_analysis.py
└── Week_5_Comprehensive_Data_Science_Project_Report.docx
```

### Run
Install:
`pip install numpy pandas scikit-learn`

Then:
`python customer_churn_analysis.py`
